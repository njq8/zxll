# What is v_mails
Is a simple tool for checking emails.
All emails can be checked.

* if you find any ERROR, please contact me.
```
   Telegram : kadaone
   Facebook : Facebook.com/zxlll
```
# Installation
* [USING] :
```
   pkg update upgrade
   pkg install git python2
   git clone https://github.com/zxllkada/zxll
   cd zxll
```
# Setup
```
   pip2 install -r requirements.txt
```
# Running 
```
   python2 v_mails.py
```
# zxll [IMG]
<img src=zxll.jpg>
<img src=kadaone.jpg>
